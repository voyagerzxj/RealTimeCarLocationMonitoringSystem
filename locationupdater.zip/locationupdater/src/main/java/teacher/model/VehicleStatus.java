package teacher.model;

/**
 * Created by teacher on 12/19/16.
 */
public enum VehicleStatus {
    NONE, SERVICE_INFO, SERVICE_SOON, SERVICE_NOW, STOP_NOW
}
